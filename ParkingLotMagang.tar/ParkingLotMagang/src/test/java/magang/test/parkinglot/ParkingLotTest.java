package magang.test.parkinglot;

import com.magang.parkinglot.ParkinglotManager;
import org.junit.After;
import java.io.ByteArrayOutputStream;

import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import java.io.PrintStream;


public class ParkingLotTest {
    ParkinglotManager parkingLot = new ParkinglotManager();
    private final ByteArrayOutputStream Out = new ByteArrayOutputStream();
    @Before
    public void setUpStreams() {
        System.setOut(new PrintStream(Out));
    }

    @After
    public void cleanUpStreams() {
        System.setOut(null);
    }
    @Test
    public void createParkingLot() throws Exception {
        parkingLot.createParkingLot("6");
        assertEquals(6, parkingLot.MAX_PARKING_SIZE);
        assertEquals(6, parkingLot.availableParkSlot.size());
        assertTrue("createdparkinglotwith6slots".equalsIgnoreCase(Out.toString().trim().replace(" ", "")));
    }

    @Test
    public void park() throws Exception {
        parkingLot.park("KA-01-HH-1234", "Blue");
        
        parkingLot.createParkingLot("6");
        parkingLot.park("KA-01-HH-900", "White");
        parkingLot.park("KA-01-HH-939", "Black");
        assertEquals(4, parkingLot.availableParkSlot.size());
    }

    @Test
    public void leave() throws Exception {
        parkingLot.leave("2");
        assertEquals("Sorry,parkinglotisnotcreated", Out.toString().trim().replace(" ", ""));
        parkingLot.createParkingLot("6");
        parkingLot.park("KB-03", "Grey");
        parkingLot.park("K3-02-HH-", "Red");
        parkingLot.leave("4");
    }

    @Test
    public void status() throws Exception {
        parkingLot.status();
        assertEquals("Sorry,parkinglotisnotcreated", Out.toString().trim().replace(" ", ""));
        parkingLot.createParkingLot("6");
        parkingLot.park("KA-01-HH-33", "Red");
        parkingLot.park("KA-01-HH-11", "Red");
        parkingLot.status();

    }

    @Test
    public void getRegistrationNumbersFromColor() throws Exception {
        parkingLot.getRegistrationNumbersFromColor("White");
        assertEquals("Sorry,parkinglotisnotcreated", Out.toString().trim().replace(" ", ""));
        parkingLot.createParkingLot("6");
        parkingLot.park("KA-01-HH-9999", "White");
        parkingLot.getRegistrationNumbersFromColor("White");
        parkingLot.getRegistrationNumbersFromColor("Red");
    }

    @Test
    public void getSlotNumbersFromColor() throws Exception {
        parkingLot.getSlotNumbersFromColor("White");
        assertEquals("Sorry,parkinglotisnotcreated", Out.toString().trim().replace(" ", ""));
        parkingLot.createParkingLot("6");
        parkingLot.park("KA-01-HH-1234", "White");
        parkingLot.getSlotNumbersFromColor("Red");
    }

    @Test
    public void getSlotNumberFromRegNo() throws Exception {
        parkingLot.getSlotNumberFromRegNo("KA-01-HH-1234");
        assertEquals("Sorry,parkinglotisnotcreated", Out.toString().trim().replace(" ", ""));
        parkingLot.createParkingLot("6");
        parkingLot.park("KA-01-HH-1234", "White");
        parkingLot.park("KA-01-HH-9999", "White");
        parkingLot.getSlotNumberFromRegNo("KA-01-HH-1234");
        parkingLot.getSlotNumberFromRegNo("KA-01-HH-9999");
        parkingLot.leave("1");
        parkingLot.getSlotNumberFromRegNo("KA-01-HH-1234");
    }

}