package magang.test.parkinglot;

import com.magang.parkinglot.ParkingCommandManager;

import static org.junit.Assert.*;


import org.junit.Test;

public class CommandManagerTest {
    ParkingCommandManager TestCommands = new ParkingCommandManager();
    
    
    @Test
    public void checkCommandInListCommandManager() throws Exception {
        assertFalse(TestCommands.ParkingCommandList.isEmpty());
        assertTrue(TestCommands.ParkingCommandList.containsKey("create_parking_lot"));
        assertTrue(TestCommands.ParkingCommandList.containsKey("leave"));
        assertTrue(TestCommands.ParkingCommandList.containsKey("status"));
        assertTrue(TestCommands.ParkingCommandList.containsKey("park"));
    }
}