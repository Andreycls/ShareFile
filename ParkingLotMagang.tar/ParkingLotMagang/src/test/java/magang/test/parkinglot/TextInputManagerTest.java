package magang.test.parkinglot;

import com.magang.parkinglot.TextInputManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;

public class TextInputManagerTest {
    TextInputManager InputTest = new TextInputManager();
    
    private final ByteArrayOutputStream contentTest = new ByteArrayOutputStream();
    
    @Test
    public void testTextInput() throws Exception {
        InputTest.parseTextInput("Test");
        assertEquals("Invalidinput", contentTest.toString().trim().replace(" ", ""));
        InputTest.parseTextInput("status");
     }
    @Before
    public void setUpStreams() {
        System.setOut(new PrintStream(contentTest));
    }

    @After
    public void cleanUpStreams() {
        System.setOut(null);
    }

}