package com.magang.parkinglot;






import java.util.*;
public class ParkinglotManager {
    public int MAX_PARKING_SIZE = 0;
    private class Car {
        String regisNo;
        String color;
        public Car(String regisNo, String color) {
            this.regisNo = regisNo;
            this.color = color;
        }
    }
    // Available slots list
    public ArrayList<Integer> availableParkSlot;
    // Map of Slot, Car
    Map<String, Car> MapPark_1;
    // Map of RegNo, Slot
    Map<String, String> MapPark_2;
    // Map of Color, List of RegNo
    Map<String, ArrayList<String>> MapPark_3;


    public void createParkingLot(String lotCount) {
        try {
            this.MAX_PARKING_SIZE = Integer.parseInt(lotCount);
        } catch (Exception e) {
            System.out.println("Invalid count");
            System.out.println();
        }
        this.availableParkSlot = new ArrayList<Integer>() {};
        for (int i=1; i<= this.MAX_PARKING_SIZE; i++) {
            availableParkSlot.add(i);
        }
        this.MapPark_1 = new HashMap<String, Car>();
        this.MapPark_2 = new HashMap<String, String>();
        this.MapPark_3 = new HashMap<String, ArrayList<String>>();
        System.out.println("Created parking lot with " + lotCount + " slots");
        System.out.println();
    }
   
    public void park(String regisNo, String color) {
        if (this.MAX_PARKING_SIZE == 0) {
            System.out.println("Sorry, parking lot is not created");
            System.out.println();
        } else if (this.MapPark_1.size() == this.MAX_PARKING_SIZE) {
            System.out.println("Sorry, parking lot is full");
            System.out.println();
        } else {
            Collections.sort(availableParkSlot);
            String slot = availableParkSlot.get(0).toString();
            Car car = new Car(regisNo, color);
            this.MapPark_1.put(slot, car);
            this.MapPark_2.put(regisNo, slot);
            if (this.MapPark_3.containsKey(color)) {
                ArrayList<String> regisNoList = this.MapPark_3.get(color);
                this.MapPark_3.remove(color);
                regisNoList.add(regisNo);
                this.MapPark_3.put(color, regisNoList);
            } else {
                ArrayList<String> regisNoList = new ArrayList<String>();
                regisNoList.add(regisNo);
                this.MapPark_3.put(color, regisNoList);
            }
            System.out.println("Allocated slot number: " + slot);
            System.out.println();
            availableParkSlot.remove(0);
        }
    }
    public void leave(String slotNo) {
        if (this.MAX_PARKING_SIZE == 0) {
            System.out.println("Sorry, parking lot is not created");
            System.out.println();
        } else if (this.MapPark_1.size() > 0) {
            Car carToLeave = this.MapPark_1.get(slotNo);
            if (carToLeave != null) {
                this.MapPark_1.remove(slotNo);
                this.MapPark_2.remove(carToLeave.regisNo);
                ArrayList<String> regisNoList = this.MapPark_3.get(carToLeave.color);
                if (regisNoList.contains(carToLeave.regisNo)) {
                    regisNoList.remove(carToLeave.regisNo);
                }
                
                this.availableParkSlot.add(Integer.parseInt(slotNo));
                System.out.println("Slot number " + slotNo + " is free");
                System.out.println();
            } else {
                System.out.println("Slot number " + slotNo + " is already empty");
                System.out.println();
            }
        } else {
            System.out.println("Parking lot is empty");
            System.out.println();
        }
    }
    public void status() {
        if (this.MAX_PARKING_SIZE == 0) {
            System.out.println("Sorry, parking lot is not created");
            System.out.println();
        } else if (this.MapPark_1.size() > 0) {
            // cetak status parkir 
            System.out.println("Slot No.\t\tRegistration No.\t\tColor");
            Car car;
            for (int i = 1; i <= this.MAX_PARKING_SIZE; i++) {
                String key = Integer.toString(i);
                if (this.MapPark_1.containsKey(key)) {
                    car = this.MapPark_1.get(key);
                    System.out.println(i + "\t\t\t" + car.regisNo + "\t\t\t\t" + car.color);
                }
            }
            System.out.println();
        } else {
            System.out.println("Parking lot is empty");
            System.out.println();
        }
    }
    public void getRegistrationNumbersFromColor(String color) {
        if (this.MAX_PARKING_SIZE == 0) {
            System.out.println("Sorry, parking lot is not created");
            System.out.println();
        } else if (this.MapPark_3.containsKey(color)) {
            ArrayList<String> regisNoList = this.MapPark_3.get(color);
            System.out.println();
            for (int i=0; i < regisNoList.size(); i++) {
                if (!(i==regisNoList.size() - 1)){
                    System.out.print(regisNoList.get(i) + ",");
                } else {
                    System.out.print(regisNoList.get(i));
                }
            }
        } else {
            System.out.println("Not found");
            System.out.println();
        }
    }
    public void getSlotNumbersFromColor(String color) {
        if (this.MAX_PARKING_SIZE == 0) {
            System.out.println("Sorry, parking lot is not created");
            System.out.println();
        } else if (this.MapPark_3.containsKey(color)) {
            ArrayList<String> regisNoList = this.MapPark_3.get(color);
            ArrayList<Integer> slotList = new ArrayList<Integer>();
            System.out.println();
            for (int i=0; i < regisNoList.size(); i++) {
                slotList.add(Integer.valueOf(this.MapPark_2.get(regisNoList.get(i))));
            }
            Collections.sort(slotList);
            for (int j=0; j < slotList.size(); j++) {
                if (!(j == slotList.size() - 1)) {
                    System.out.print(slotList.get(j) + ",");
                } else {
                    System.out.print(slotList.get(j));
                }
            }
            System.out.println();
        } else {
            System.out.println("Not found");
            System.out.println();
        }
    }
    public void getSlotNumberFromRegNo(String regisNo) {
        if (this.MAX_PARKING_SIZE == 0) {
            System.out.println("Sorry, parking lot is not created");
            System.out.println();
        } else if (this.MapPark_2.containsKey(regisNo)) {
            System.out.println(this.MapPark_2.get(regisNo));
        } else {
            System.out.println("Not found");
            System.out.println();
        }
    }
}
