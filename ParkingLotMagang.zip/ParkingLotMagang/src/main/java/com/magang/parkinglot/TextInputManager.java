package com.magang.parkinglot;

import java.io.FileReader;

import java.io.FileNotFoundException;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.io.BufferedReader;

public class TextInputManager {
    ParkingCommandManager ParkingCommands;
    static ParkinglotManager ParkingTest;
    public TextInputManager() {
        ParkingCommands = new ParkingCommandManager();
        ParkingTest = new ParkinglotManager();
    }
    public void parseTextInput(String inputString) {
        // Split the input string to get command and input value
        String[] inputs = inputString.split(" ");
        switch (inputs.length) {
            case 1:
                try {
                    Method ParkMethod = ParkingCommands.ParkingCommandList.get(inputString);
                    if (ParkMethod != null) {
                        ParkMethod.invoke(ParkingTest);
                    } else {
                        System.out.println("Invalid input");
                    }
                } catch (IllegalAccessException ez) {
                    ez.printStackTrace();
                }   catch (InvocationTargetException I) {
                                I.printStackTrace();
                }
                        break;
            case 2:
                try {
                         Method ParkMethod = ParkingCommands.ParkingCommandList.get(inputs[0]);
                    if (ParkMethod != null) {
                        ParkMethod.invoke(ParkingTest, inputs[1]);
                    } else {
                        System.out.println("Invalid input");
                    }
                } catch (IllegalAccessException ill) {
                    ill.printStackTrace();
                } catch (InvocationTargetException Inv) {
                    Inv.printStackTrace();
                }
                break;
            case 3:
                try {
                    Method ParkMethod = ParkingCommands.ParkingCommandList.get(inputs[0]);
                    if (ParkMethod != null) {
                        ParkMethod.invoke(ParkingTest, inputs[1], inputs[2]);
                    } else {
                        System.out.println("Invalid input");
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
                break;
            default:
                System.out.println("Invalid input.");
        }
    }

    public void parseFileInput(String filePath) {
        File inputFile = new File(filePath);

            try {
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            String line;
                try {
                    while ((line = br.readLine()) != null) {
                        parseTextInput(line.trim());
                }
            } catch (IOException ex) {
                System.out.println("Error read file.");
                ex.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
            
        }
    }
}
