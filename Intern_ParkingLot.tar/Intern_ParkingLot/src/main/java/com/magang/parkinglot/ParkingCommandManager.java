package com.magang.parkinglot;


import java.util.Map;
import java.lang.reflect.Method;

import java.util.HashMap;

public class ParkingCommandManager {
    public Map<String, Method> ParkingCommandList;

    private void ListOfCommands() throws Exception {
        ParkingCommandList.put("create_parking_lot", ParkinglotManager.class.getMethod("createParkingLot", String.class));
                ParkingCommandList.put("park", ParkinglotManager.class.getMethod("park", String.class, String.class));
            ParkingCommandList.put("leave", ParkinglotManager.class.getMethod("leave", String.class));
        ParkingCommandList.put("status", ParkinglotManager.class.getMethod("status"));
        
        ParkingCommandList.put("slot_number_for_registration_number", ParkinglotManager.class.getMethod("getSlotNumberFromRegNo", String.class));
            ParkingCommandList.put("slot_numbers_for_cars_with_colour", ParkinglotManager.class.getMethod("getSlotNumbersFromColor", String.class));
    ParkingCommandList.put("registration_numbers_for_cars_with_colour", ParkinglotManager.class.getMethod("getRegistrationNumbersFromColor", String.class));
        
    }
    
        public ParkingCommandManager() {
        
            ParkingCommandList = new HashMap<String, Method>();
            
                try {
                ListOfCommands();
                 } catch (Exception e) {
                    }
        }
    
}
